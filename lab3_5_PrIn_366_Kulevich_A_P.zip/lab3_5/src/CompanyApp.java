public class CompanyApp {
    public static void main (String[] args) {

    }
}
